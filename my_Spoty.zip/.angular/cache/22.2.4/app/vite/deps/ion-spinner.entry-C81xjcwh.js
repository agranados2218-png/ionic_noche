import { a as config, p as h, r as Host, v as registerInstance } from "./index-BpRUsN_W-Dyk8UFjA.js";
import { t as getIonMode } from "./ionic-global-Cep6oYzK-DYtGOxOW.js";
import { t as createColorClasses } from "./theme-byZM6qHV-CVcL0HyM.js";
import { t as SPINNERS } from "./spinner-configs-D4RIp70E-H9KnQ5S7.js";
//#region node_modules/@ionic/core/dist/esm/ion-spinner.entry.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var spinnerCss = () => `:host{display:inline-block;position:relative;width:28px;height:28px;color:var(--color);-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}:host(.ion-color){color:var(--ion-color-base)}svg{-webkit-transform-origin:center;transform-origin:center;position:absolute;top:0;left:0;width:100%;height:100%;-webkit-transform:translateZ(0);transform:translateZ(0)}:host-context([dir=rtl]) svg{-webkit-transform-origin:calc(100% - center);transform-origin:calc(100% - center)}[dir=rtl] svg{-webkit-transform-origin:calc(100% - center);transform-origin:calc(100% - center)}@supports selector(:dir(rtl)){svg:dir(rtl){-webkit-transform-origin:calc(100% - center);transform-origin:calc(100% - center)}}:host(.spinner-lines) line,:host(.spinner-lines-small) line{stroke-width:7px}:host(.spinner-lines-sharp) line,:host(.spinner-lines-sharp-small) line{stroke-width:4px}:host(.spinner-lines) line,:host(.spinner-lines-small) line,:host(.spinner-lines-sharp) line,:host(.spinner-lines-sharp-small) line{stroke-linecap:round;stroke:currentColor}:host(.spinner-lines) svg,:host(.spinner-lines-small) svg,:host(.spinner-lines-sharp) svg,:host(.spinner-lines-sharp-small) svg{-webkit-animation:spinner-fade-out 1s linear infinite;animation:spinner-fade-out 1s linear infinite}:host(.spinner-bubbles) svg{-webkit-animation:spinner-scale-out 1s linear infinite;animation:spinner-scale-out 1s linear infinite;fill:currentColor}:host(.spinner-circles) svg{-webkit-animation:spinner-fade-out 1s linear infinite;animation:spinner-fade-out 1s linear infinite;fill:currentColor}:host(.spinner-crescent) circle{fill:transparent;stroke-width:4px;stroke-dasharray:128px;stroke-dashoffset:82px;stroke:currentColor}:host(.spinner-crescent) svg{-webkit-animation:spinner-rotate 1s linear infinite;animation:spinner-rotate 1s linear infinite}:host(.spinner-dots) circle{stroke-width:0;fill:currentColor}:host(.spinner-dots) svg{-webkit-animation:spinner-dots 1s linear infinite;animation:spinner-dots 1s linear infinite}:host(.spinner-circular) svg{-webkit-animation:spinner-circular linear infinite;animation:spinner-circular linear infinite}:host(.spinner-circular) circle{-webkit-animation:spinner-circular-inner ease-in-out infinite;animation:spinner-circular-inner ease-in-out infinite;stroke:currentColor;stroke-dasharray:80px, 200px;stroke-dashoffset:0px;stroke-width:5.6;fill:none}:host(.spinner-paused),:host(.spinner-paused) svg,:host(.spinner-paused) circle{-webkit-animation-play-state:paused;animation-play-state:paused}@-webkit-keyframes spinner-fade-out{0%{opacity:1}100%{opacity:0}}@keyframes spinner-fade-out{0%{opacity:1}100%{opacity:0}}@-webkit-keyframes spinner-scale-out{0%{-webkit-transform:scale(1, 1);transform:scale(1, 1)}100%{-webkit-transform:scale(0, 0);transform:scale(0, 0)}}@keyframes spinner-scale-out{0%{-webkit-transform:scale(1, 1);transform:scale(1, 1)}100%{-webkit-transform:scale(0, 0);transform:scale(0, 0)}}@-webkit-keyframes spinner-rotate{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes spinner-rotate{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@-webkit-keyframes spinner-dots{0%{-webkit-transform:scale(1, 1);transform:scale(1, 1);opacity:0.9}50%{-webkit-transform:scale(0.4, 0.4);transform:scale(0.4, 0.4);opacity:0.3}100%{-webkit-transform:scale(1, 1);transform:scale(1, 1);opacity:0.9}}@keyframes spinner-dots{0%{-webkit-transform:scale(1, 1);transform:scale(1, 1);opacity:0.9}50%{-webkit-transform:scale(0.4, 0.4);transform:scale(0.4, 0.4);opacity:0.3}100%{-webkit-transform:scale(1, 1);transform:scale(1, 1);opacity:0.9}}@-webkit-keyframes spinner-circular{100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes spinner-circular{100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@-webkit-keyframes spinner-circular-inner{0%{stroke-dasharray:1px, 200px;stroke-dashoffset:0px}50%{stroke-dasharray:100px, 200px;stroke-dashoffset:-15px}100%{stroke-dasharray:100px, 200px;stroke-dashoffset:-125px}}@keyframes spinner-circular-inner{0%{stroke-dasharray:1px, 200px;stroke-dashoffset:0px}50%{stroke-dasharray:100px, 200px;stroke-dashoffset:-15px}100%{stroke-dasharray:100px, 200px;stroke-dashoffset:-125px}}`;
var Spinner = class {
	constructor(hostRef) {
		registerInstance(this, hostRef);
		/**
		* If `true`, the spinner's animation will be paused.
		*/
		this.paused = false;
	}
	getName() {
		const spinnerName = this.name || config.get("spinner");
		const mode = getIonMode(this);
		if (spinnerName) return spinnerName;
		return mode === "ios" ? "lines" : "circular";
	}
	render() {
		const self = this;
		const mode = getIonMode(self);
		const spinnerName = self.getName();
		const spinner = SPINNERS[spinnerName] ?? SPINNERS["lines"];
		const duration = typeof self.duration === "number" && self.duration > 10 ? self.duration : spinner.dur;
		const svgs = [];
		if (spinner.circles !== void 0) for (let i = 0; i < spinner.circles; i++) svgs.push(buildCircle(spinner, duration, i, spinner.circles));
		else if (spinner.lines !== void 0) for (let i = 0; i < spinner.lines; i++) svgs.push(buildLine(spinner, duration, i, spinner.lines));
		return h(Host, {
			key: "87102ff9ea58b0ecde5d0978386374f7d0e9cf98",
			class: createColorClasses(self.color, {
				[mode]: true,
				[`spinner-${spinnerName}`]: true,
				"spinner-paused": self.paused || config.getBoolean("_testing")
			}),
			role: "progressbar",
			style: spinner.elmDuration ? { animationDuration: duration + "ms" } : {}
		}, svgs);
	}
};
var buildCircle = (spinner, duration, index, total) => {
	const data = spinner.fn(duration, index, total);
	data.style["animation-duration"] = duration + "ms";
	return h("svg", {
		viewBox: data.viewBox || "0 0 64 64",
		style: data.style
	}, h("circle", {
		transform: data.transform || "translate(32,32)",
		cx: data.cx,
		cy: data.cy,
		r: data.r,
		style: spinner.elmDuration ? { animationDuration: duration + "ms" } : {}
	}));
};
var buildLine = (spinner, duration, index, total) => {
	const data = spinner.fn(duration, index, total);
	data.style["animation-duration"] = duration + "ms";
	return h("svg", {
		viewBox: data.viewBox || "0 0 64 64",
		style: data.style
	}, h("line", {
		transform: "translate(32,32)",
		y1: data.y1,
		y2: data.y2
	}));
};
Spinner.style = spinnerCss();
//#endregion
export { Spinner as ion_spinner };
