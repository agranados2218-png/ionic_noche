import { a as config, b as setMode, f as getMode, h as printIonWarning, o as configFromSession, s as configFromURL, y as saveConfig } from "./index-BpRUsN_W-Dyk8UFjA.js";
//#region node_modules/@ionic/core/dist/esm/ionic-global-Cep6oYzK.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var getPlatforms = (win) => setupPlatforms(win);
var isPlatform = (winOrPlatform, platform) => {
	if (typeof winOrPlatform === "string") {
		platform = winOrPlatform;
		winOrPlatform = void 0;
	}
	return getPlatforms(winOrPlatform).includes(platform);
};
var setupPlatforms = (win = window) => {
	if (typeof win === "undefined") return [];
	win.Ionic = win.Ionic || {};
	let platforms = win.Ionic.platforms;
	if (platforms == null) {
		platforms = win.Ionic.platforms = detectPlatforms(win);
		platforms.forEach((p) => win.document.documentElement.classList.add(`plt-${p}`));
	}
	return platforms;
};
var detectPlatforms = (win) => {
	const customPlatformMethods = config.get("platform");
	return Object.keys(PLATFORMS_MAP).filter((p) => {
		const customMethod = customPlatformMethods?.[p];
		return typeof customMethod === "function" ? customMethod(win) : PLATFORMS_MAP[p](win);
	});
};
var isMobileWeb = (win) => isMobile(win) && !isHybrid(win);
var isIpad = (win) => {
	if (testUserAgent(win, /iPad/i)) return true;
	if (testUserAgent(win, /Macintosh/i) && isMobile(win)) return true;
	return false;
};
var isIphone = (win) => testUserAgent(win, /iPhone/i);
var isIOS = (win) => testUserAgent(win, /iPhone|iPod/i) || isIpad(win);
var isAndroid = (win) => testUserAgent(win, /android|sink/i);
var isAndroidTablet = (win) => {
	return isAndroid(win) && !testUserAgent(win, /mobile/i);
};
var isPhablet = (win) => {
	const width = win.innerWidth;
	const height = win.innerHeight;
	const smallest = Math.min(width, height);
	const largest = Math.max(width, height);
	return smallest > 390 && smallest < 520 && largest > 620 && largest < 800;
};
var isTablet = (win) => {
	const width = win.innerWidth;
	const height = win.innerHeight;
	const smallest = Math.min(width, height);
	const largest = Math.max(width, height);
	return isIpad(win) || isAndroidTablet(win) || smallest > 460 && smallest < 820 && largest > 780 && largest < 1400;
};
var isMobile = (win) => matchMedia(win, "(any-pointer:coarse)");
var isDesktop = (win) => !isMobile(win);
var isHybrid = (win) => isCordova(win) || isCapacitorNative(win);
var isCordova = (win) => !!(win["cordova"] || win["phonegap"] || win["PhoneGap"]);
var isCapacitorNative = (win) => {
	return !!win["Capacitor"]?.isNativePlatform?.();
};
var isElectron = (win) => testUserAgent(win, /electron/i);
var isPWA = (win) => !!(win.matchMedia?.("(display-mode: standalone)").matches || win.navigator.standalone);
var testUserAgent = (win, expr) => expr.test(win.navigator.userAgent);
var matchMedia = (win, query) => win.matchMedia?.(query).matches;
var PLATFORMS_MAP = {
	ipad: isIpad,
	iphone: isIphone,
	ios: isIOS,
	android: isAndroid,
	phablet: isPhablet,
	tablet: isTablet,
	cordova: isCordova,
	capacitor: isCapacitorNative,
	electron: isElectron,
	pwa: isPWA,
	mobile: isMobile,
	mobileweb: isMobileWeb,
	desktop: isDesktop,
	hybrid: isHybrid
};
var defaultMode;
var getIonMode = (ref) => {
	return ref && getMode(ref) || defaultMode;
};
var initialize = (userConfig = {}) => {
	if (typeof window === "undefined") return;
	const doc = window.document;
	const win = window;
	const Ionic = win.Ionic = win.Ionic || {};
	const configObj = {
		...configFromSession(win),
		persistConfig: false,
		...Ionic.config,
		...configFromURL(win),
		...userConfig
	};
	config.reset(configObj);
	if (config.getBoolean("persistConfig")) saveConfig(win, configObj);
	setupPlatforms(win);
	Ionic.config = config;
	Ionic.mode = defaultMode = config.get("mode", doc.documentElement.getAttribute("mode") || (isPlatform(win, "ios") ? "ios" : "md"));
	config.set("mode", defaultMode);
	doc.documentElement.setAttribute("mode", defaultMode);
	doc.documentElement.classList.add(defaultMode);
	if (config.getBoolean("_testing")) config.set("animated", false);
	const isIonicElement = (elm) => elm.tagName?.startsWith("ION-");
	const isAllowedIonicModeValue = (elmMode) => ["ios", "md"].includes(elmMode);
	setMode((elm) => {
		while (elm) {
			const elmMode = elm.mode || elm.getAttribute("mode");
			if (elmMode) {
				if (isAllowedIonicModeValue(elmMode)) return elmMode;
				else if (isIonicElement(elm)) printIonWarning("Invalid ionic mode: \"" + elmMode + "\", expected: \"ios\" or \"md\"");
			}
			elm = elm.parentElement;
		}
		return defaultMode;
	});
};
//#endregion
export { isPlatform as i, getPlatforms as n, initialize as r, getIonMode as t };
